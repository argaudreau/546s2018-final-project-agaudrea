Progress Report Week 1
Graphics 1 Spring 2018
Programmer: Adam Gaudreau
Due: 28 March 2018

==========
 Overview
==========
This is the progress report for week 1 of the final project.

=========
 Sources
=========
I am using the three.js third party library to render everything. I only used the documentation for reference, located here: https://threejs.org/docs/index.html#manual/introduction/Creating-a-scene.
This is the best option for this project for me because it handles the complicated math behind rendering the actual shapes, so I can focus on transforming, spawning, and manipulating shapes.
The two files js/three.min/js and js/OrbitControlls.js are not made by me, but by the three.js team. Everything else was written soley by me.